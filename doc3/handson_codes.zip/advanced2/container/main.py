from rdetoolkit import workflows

from modules.datasets_process import dataset


def main():
    workflows.run(
        custom_dataset_function=dataset
    )

if __name__ == '__main__':
    main()
