from rdetoolkit.models.rde2types import RdeInputDirPaths, RdeOutputResourcePath
from rdetoolkit.errors import catch_exception_with_message
from rdetoolkit.invoicefile import InvoiceFile

from modules.custom_process import CustomProcess
from modules.custom_process2 import CustomProcess2


@catch_exception_with_message(error_message="ERROR: failed in data processing", error_code=50)
def dataset(srcpaths: RdeInputDirPaths, resource_paths: RdeOutputResourcePath) -> None:
    # Parse invoice
    invoice_file = resource_paths.invoice.joinpath("invoice.json")
    invoice = InvoiceFile(invoice_file).invoice_obj

    ## Create Instance of Custom Process
    if invoice["custom"]["data_type"] == 'variant':
        custom_process = CustomProcess2(srcpaths, resource_paths)
    else:
        custom_process = CustomProcess(srcpaths, resource_paths)

    # Do some ...
    custom_process.check_input()
    custom_process.parse_invoice()
    custom_process.backup_invoice_file("invoice.json.orig")
    custom_process.update_invoice()
    custom_process.parse_input()
    custom_process.make_meta()
    custom_process.make_struct()
    custom_process.make_graph()
    custom_process.make_thumbnail()
    custom_process.copy_raw_files()
