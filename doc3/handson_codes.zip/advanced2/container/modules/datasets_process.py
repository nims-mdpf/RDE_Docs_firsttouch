from rdetoolkit.models.rde2types import RdeDatasetPaths
from rdetoolkit.errors import catch_exception_with_message
from rdetoolkit.invoicefile import InvoiceFile

from modules.custom_process import CustomProcess
from modules.custom_process2 import CustomProcess2


@catch_exception_with_message(error_message="ERROR: failed in data processing", error_code=50)
def dataset(paths: RdeDatasetPaths) -> None:
    # Parse invoice
    invoice_file = paths.invoice.joinpath("invoice.json")
    invoice = InvoiceFile(invoice_file).invoice_obj

    ## Create Instance of Custom Process
    if invoice["custom"]["data_type"] == 'variant':
        custom_process = CustomProcess2(paths)
    else:
        custom_process = CustomProcess(paths)

    # Do some ...
    custom_process.check_input()
    custom_process.parse_invoice()
    custom_process.backup_invoice_file("invoice.json.orig")
    custom_process.update_invoice()
    custom_process.parse_input()
    custom_process.make_meta()
    custom_process.make_struct()
    custom_process.make_graph()
    custom_process.make_thumbnail()
    custom_process.copy_raw_files()
