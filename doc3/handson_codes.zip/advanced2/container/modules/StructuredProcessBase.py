from rdetoolkit.models.rde2types import RdeInputDirPaths, RdeOutputResourcePath
from rdetoolkit.exceptions import StructuredError


class StructuredProcessBase:
    def __init__(self, srcpaths: RdeInputDirPaths, resource_paths: RdeOutputResourcePath):
        self.srcpaths = srcpaths
        self.resource_paths = resource_paths

    def check_input(self):
        raise NotImplementedError

    def parse_invoice(self):
        raise NotImplementedError

    def update_invoice(self, newInvoiceDict = None):
        raise NotImplementedError

    def copy_raw_files(self):
        raise NotImplementedError

    def make_meta(self):
        raise NotImplementedError

    def make_struct(self):
        raise NotImplementedError

    def make_graph(self):
        raise NotImplementedError

    def make_thumbnail(self):
        raise NotImplementedError
