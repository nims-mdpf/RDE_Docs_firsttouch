import io
import statistics as st
import shutil
from pprint import pprint

import pandas as pd
import matplotlib.pyplot as plt
from PIL import Image

from rdetoolkit.models.rde2types import RdeInputDirPaths, RdeOutputResourcePath
from rdetoolkit.errors import StructuredError
from rdetoolkit.fileops import readf_json, writef_json
from rdetoolkit.rde2util import Meta
from rdetoolkit.rdelogger import CustomLog, log_decorator

from modules.StructuredProcessBase import StructuredProcessBase


logger = CustomLog().get_logger()

class CustomProcess(StructuredProcessBase):
    additional_title = "(2024)"

    @log_decorator()
    def __init__(self, srcpaths: RdeInputDirPaths, resource_paths: RdeOutputResourcePath):
        super().__init__(srcpaths, resource_paths)
        self.invoice_file = resource_paths.invoice.joinpath('invoice.json')
        self.data_df = None
        self.const_meta_info = dict()
        self.repeated_meta_info = dict()
        self.is_private_row = None

    @log_decorator()
    def check_input(self) -> bool:
        # Check input file
        input_files = self.resource_paths.rawfiles
        if len(input_files) == 0:
            raise StructuredError("ERROR: input data not found")
        if len(input_files) > 1:
            raise StructuredError("ERROR: input data should be one file")
        raw_file_path = input_files[0]
        if raw_file_path.suffix.lower() != ".data":
            raise StructuredError(
                f"ERROR: input file is not '*.data' : {raw_file_path.name}"
            )
        return True

    @log_decorator()
    def parse_input(self) -> None:
        # Read input data
        DELIM = "="
        raw_data_df = None
        raw_meta_obj = None
        #
        input_file = self.resource_paths.rawfiles[0]

        with open(input_file) as f:
            lines = f.readlines()
        # omit new line codes (\r and \n)
        lines_strip = [line.strip() for line in lines]

        meta_row = [i for i, line in enumerate(lines_strip) if "[METADATA]" in line]
        data_row = [i for i, line in enumerate(lines_strip) if "[DATA]" in line]
        if (meta_row != []) & (data_row != []):
            meta = lines_strip[(meta_row[0]+1):data_row[0]]
            # metadata to dict
            raw_meta_obj = dict(map(lambda x: tuple([x.split(DELIM)[0],
                        DELIM.join(x.split(DELIM)[1:])]), meta))
        else:
            raise StructuredError("ERROR: invalid RAW METADATA or DATA")

        # read data to data.frame
        if (int(raw_meta_obj["series_number"]) != len(data_row)):
            raise StructuredError("ERROR: unmatch series number")
        raw_data_df = []
        for i in data_row:
            series_name = lines_strip[i+1]
            cnt = int(lines_strip[i+2])
            csv = "".join(lines[(i+3):(i+3+cnt)])
            temp_df = pd.read_csv(io.StringIO(csv),header=None)
            temp_df.columns = ["x", series_name]
            raw_data_df.append(temp_df)
        #
        self.const_meta_info = self.const_meta_info | raw_meta_obj
        self.data_df = raw_data_df

    @log_decorator()
    def parse_invoice(self) -> None:
        self.invoice_dict = readf_json(self.invoice_file)
        self.is_private_raw = self._is_private_raw()
        #pprint(self.is_private_raw)

    def _is_private_raw(self) -> bool:
        invoice_dict = self.invoice_dict
        # Check private or not
        custom = invoice_dict.get("custom")
        if custom is None:
            return False
        is_private_raw = custom.get("is_private_raw")
        if is_private_raw == "share":
            return False
        # other case -> "private"
        return True

    @log_decorator()
    def update_invoice(self, new_invoice_dict = None) -> None:
        if new_invoice_dict is not None:
            self.invoice_dict = new_invoice_dict
        else:
            self._update_invoice()
        # overwrite invoice.json
        self._overwrite_invoice_file()

    def _update_invoice(self) -> None:
        # Update invoice title
        original_data_name = self.invoice_dict["basic"]["dataName"]
        additional_title = self.additional_title
        if original_data_name.find(additional_title) < 0:
            # update title if not applied yet
            self.invoice_dict["basic"]["dataName"] = \
                original_data_name + " / " + additional_title

    def _overwrite_invoice_file(self) -> None:
        # Overwrite Invoice file
        invoice_file_new = self.invoice_file
        writef_json(invoice_file_new, self.invoice_dict)

    def backup_invoice_file(self, backup_file = None) -> None:
        # Backup(=Copy) invoice.json to shared/nonshared folder
        is_private_raw = self.is_private_raw
        if is_private_raw:
            raw_dir = self.resource_paths.nonshared_raw
        else:
            raw_dir = self.resource_paths.raw
        if backup_file is None:
            backup_file = "invoice_backup.json"
        invoice_file_new = raw_dir.joinpath(backup_file)
        writef_json(invoice_file_new, self.invoice_dict)

    @log_decorator()
    def copy_raw_files(self) -> None:
        # Copy inputdata to public (raw/) or non_public (nonshared_raw/)
        is_private_raw = self.is_private_raw
        raw_dir = self.resource_paths.nonshared_raw if is_private_raw else self.resource_paths.raw
        for input_file in self.resource_paths.rawfiles:
            shutil.copy(input_file, raw_dir)

    @log_decorator()
    def make_meta(self) -> None:
        # create meta and save meta
        self._parse_from_invoice()
        self._parse_from_inputdata()
        save_path = self.resource_paths.meta.joinpath("metadata.json")
        self._save_meta(save_path)

    def _parse_from_invoice(self) -> None:
        # Merge invoice info to meta
        if self.invoice_dict["custom"] is not None:
            self.const_meta_info = self.const_meta_info | self.invoice_dict["custom"]

    def _parse_from_inputdata(self) -> None:
        data = self.data_df

        # From raw data numeric data part
        s_name = []
        s_count = []
        s_mean = []
        s_median = []
        s_max = []
        s_min = []
        s_stdev = []

        for df in data:
            d = df.dropna(axis=0)
            y = d.iloc[:, 1]
            s_name.append(d.columns[1])
            s_count.append(len(y))
            s_mean.append("{:.2f}".format(st.mean(y)))
            s_median.append("{:.2f}".format(st.median(y)))
            s_max.append(max(y))
            s_min.append(min(y))
            s_stdev.append("{:.2f}".format(st.stdev(y)))

        meta_vars = {
            "series_name": s_name,
            "series_data_count": s_count,
            "series_data_mean": s_mean,
            "series_data_median": s_median,
            "series_data_max": s_max,
            "series_data_min": s_min,
            "series_data_stdev": s_stdev,
        }

        # Set variable meta
        self.repeated_meta_info = meta_vars

    def _save_meta(self, save_path) -> None:
        # Save metadata to file
        metadef_filepath = self.srcpaths.tasksupport.joinpath("metadata-def.json")
        metaobj = Meta(metadef_filepath)
        metaobj.assign_vals(self.const_meta_info)
        metaobj.assign_vals(self.repeated_meta_info)

        metaobj.writefile(save_path)


    @log_decorator()
    def make_struct(self) -> None:
        # Write CSV file(s)
        for d in self.data_df:
            fname = d.columns[1].replace(" ", "") + ".csv"
            csv_file_path = self.resource_paths.struct.joinpath(fname)
            d.to_csv(csv_file_path, header=True, index=False)

    @log_decorator()
    def make_graph(self,title = None, xlabel = None , ylabel = None) -> None:
        # Write Graph
        title = title if title is not None else "No title"
        xlabel = xlabel if xlabel is not None else "X-label"
        ylabel = ylabel if ylabel is not None else "Y-label"

        ## by series
        for d in self.data_df:
            x = d.iloc[:, 0]
            y = d.iloc[:, 1]
            label = d.columns[1]
            fname = self.resource_paths.other_image.joinpath(f"{label}.png")
            fig, ax = plt.subplots(figsize=(5, 5), facecolor="white")
            ax.plot(x, y, label=label)
            ax.set_title(title)
            ax.set_xlabel(xlabel)
            ax.set_ylabel(ylabel)
            ax.legend()
            fig.savefig(fname)
            plt.close(fig)

        ## all series
        fig, ax = plt.subplots(figsize=(5, 5), facecolor="lightblue")
        ax.set_xlabel(xlabel)
        ax.set_ylabel(ylabel)
        ax.set_title(title)
        for d in self.data_df:
            x = d.iloc[:, 0]
            y = d.iloc[:, 1]
            label = d.columns[1]
            ax.plot(x, y, label=label)
        ax.legend()
        fname = self.resource_paths.main_image.joinpath("all_series.png")
        fig.savefig(fname)
        plt.close(fig)

    @log_decorator()
    def make_thumbnail(self) -> None:
        # Write thumbnail images
        src_path = self.resource_paths.main_image
        src_img_file_path = src_path.joinpath("all_series.png")
        save_path = self.resource_paths.thumbnail
        out_img_file_path = save_path.joinpath("thumbnail.png")

        # Size of thumbnail
        closure_w = 286
        closure_h = 200

        Image.MAX_IMAGE_PIXELS = None
        img_org = Image.open(src_img_file_path)
        ratio_w = closure_w / img_org.width
        ratio_h = closure_h / img_org.height
        ratio = min(ratio_w, ratio_h)
        img_re = img_org.resize(
            (int(img_org.width * ratio), int(img_org.height * ratio)),
            Image.BILINEAR
        )
        img_re.save(out_img_file_path)
