from modules.custom_process import CustomProcess


class CustomProcess2(CustomProcess):
    additional_title = "(2025)"
