from rdetoolkit.models.rde2types import RdeInputDirPaths, RdeOutputResourcePath
from rdetoolkit.invoicefile import InvoiceFile
from rdetoolkit.rdelogger import CustomLog, log_decorator

from modules.custom_process import CustomProcess


logger = CustomLog().get_logger()

class CustomProcess2(CustomProcess):
    @log_decorator()
    def __init__(self, srcpaths: RdeInputDirPaths, resource_paths: RdeOutputResourcePath):
        super().__init__(srcpaths, resource_paths)

    def _update_invoice(self) -> None:
        # Update invoice title
        original_data_name = self.invoice_dict["basic"]["dataName"]
        additional_title = "(2025)"
        if original_data_name.find(additional_title) < 0:
            # update title if not applied yet
            self.invoice_dict["basic"]["dataName"] = \
                original_data_name + " / " + additional_title
