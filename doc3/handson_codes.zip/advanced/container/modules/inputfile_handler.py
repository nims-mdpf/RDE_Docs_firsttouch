from __future__ import annotations

import io
from pathlib import Path
from typing import Any

import pandas as pd
from rdetoolkit.models.rde2types import MetaType
from rdetoolkit.errors import StructuredError

from modules.interfaces import IInputFileParser


class FileReader(IInputFileParser):

    def check(self, srcpaths: Path) -> bool:
        # Check input file
        input_dir = srcpaths.inputdata
        input_files = list(input_dir.glob("*"))

        if len(input_files) == 0:
            raise StructuredError("ERROR: input data not found")

        if len(input_files) > 1:
            raise StructuredError("ERROR: input data should be one file")

        raw_file_path = input_files[0]
        if raw_file_path.suffix.lower() != ".data":
            raise StructuredError(
                f"ERROR: input file is not '*.data' : {raw_file_path.name}"
            )

        return True

    def read(self, srcpaths: Path) -> tuple[MetaType, list[pd.DataFrame]]:
        # Read input data
        DELIM = "="
        rawDataDf = None
        rawMetaObj = None
        #
        input_dir = srcpaths.inputdata
        input_file = input_dir / "sample.data"

        with open(input_file) as f:
            lines = f.readlines()
        # omit new line codes (\r and \n)
        lines_strip = [line.strip() for line in lines]

        meta_row = [i for i, line in enumerate(lines_strip) if "[METADATA]" in line]
        data_row = [i for i, line in enumerate(lines_strip) if "[DATA]" in line]
        if (meta_row != []) & (data_row !=[]):
            meta = lines_strip[(meta_row[0]+1):data_row[0]]
            # metadata to dict
            raw_meta_obj = dict(map(lambda x: tuple([x.split(DELIM)[0],
                        DELIM.join(x.split(DELIM)[1:])]), meta))
        else:
            raise StructuredError("ERROR: invalid RAW METADATA or DATA")

        # read data to data.frame
        if (int(raw_meta_obj["series_number"])!= len(data_row)):
            raise StructuredError("ERROR: unmatch series number")
        raw_data_df = []
        for i in data_row:
            series_name = lines_strip[i+1]
            cnt = int(lines_strip[i+2])
            csv = "".join(lines[(i+3):(i+3+cnt)])
            temp_df = pd.read_csv(io.StringIO(csv),header=None)
            temp_df.columns = ["x", series_name]
            raw_data_df.append(temp_df)
        #
        return raw_meta_obj, raw_data_df

