from pprint import pprint
import shutil

from rdetoolkit.errors import catch_exception_with_message
from rdetoolkit.models.rde2types import RdeInputDirPaths, RdeOutputResourcePath
from rdetoolkit.rde2util import Meta

from modules.graph_handler import GraphPlotter
from modules.inputfile_handler import FileReader
from modules.meta_handler import MetaParser
from modules.structured_handler import StructuredDataProcessor
from modules.invoice_handler import InvoiceParser
from modules.thumbnail_handler import ThumbnailDrawer


class CustomProcessingCoordinator:

    def __init__(
        self,
        file_reader: FileReader,
        meta_parser: MetaParser,
        graph_plotter: GraphPlotter,
        structured_processor: StructuredDataProcessor,
        invoice_parser: InvoiceParser,
    ):
        self.file_reader = file_reader
        self.meta_parser = meta_parser
        self.graph_plotter = graph_plotter
        self.structured_processor = structured_processor
        self.invoice_parser = invoice_parser


def custom_module(srcpaths: RdeInputDirPaths, resource_paths: RdeOutputResourcePath) -> None:
    coordinator = CustomProcessingCoordinator(
             FileReader(),
             MetaParser(),
             GraphPlotter(),
             StructuredDataProcessor(),
             InvoiceParser(),
    )
    # Check input file
    coordinator.file_reader.check(resource_paths.rawfiles)

    # Read and Update Invoice
    invoice = coordinator.invoice_parser
    invoice.parse(resource_paths.invoice / "invoice.json")
    invoice.set_dirs(
        raw_dir = resource_paths.raw,
        nonshared_raw_dir = resource_paths.nonshared_raw,
    )
    invoice.backup()
    invoice.change_title()

    # Read Input File
    meta, df_data = coordinator.file_reader.read(resource_paths.rawfiles)

    # Meta
    meta_parser = coordinator.meta_parser
    meta_parser.parse_from_invoice(invoice.invoice_obj)
    meta_parser.parse_from_inputdata(meta, df_data)
    meta_parser.save_meta(
        resource_paths.meta.joinpath("metadata.json"),
        Meta(srcpaths.tasksupport.joinpath("metadata-def.json"))
    )

    # Save csv
    csv_save_path = resource_paths.struct #.joinpath("sample.csv")
    coordinator.structured_processor.to_csv(df_data, csv_save_path)
    # Graph
    const_meta_info = meta # or coordinator.meta_parser.const_meta_info
    coordinator.graph_plotter.plot(
        df_data,
        resource_paths,
        title=const_meta_info["data_title"],
        xlabel=const_meta_info["x_label"],
        ylabel=const_meta_info["y_label"]
    )

    # Thumbnail
    thumbnail = ThumbnailDrawer()
    thumbnail.draw(resource_paths)

    # Copy inputdata to public (raw/) or non_public (nonshared_raw/)
    is_private_raw = invoice.is_private_raw
    raw_dir = resource_paths.nonshared_raw if is_private_raw else resource_paths.raw
    for input_file in resource_paths.rawfiles:
        shutil.copy(input_file, raw_dir)

@catch_exception_with_message(error_message="ERROR: failed in data processing", error_code=50)
def dataset(srcpaths: RdeInputDirPaths, resource_paths: RdeOutputResourcePath) -> None:
    custom_module(srcpaths, resource_paths)
