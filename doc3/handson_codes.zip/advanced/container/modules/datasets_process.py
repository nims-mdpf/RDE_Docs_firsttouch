import shutil

from rdetoolkit.errors import catch_exception_with_message
from rdetoolkit.models.rde2types import RdeInputDirPaths, RdeOutputResourcePath
from rdetoolkit.rde2util import Meta

from modules.graph_handler import GraphPlotter
from modules.inputfile_handler import FileReader
from modules.meta_handler import MetaParser
from modules.structured_handler import StructuredDataProcessor
from modules.invoice_handler import InvoiceParser
from modules.thumbnail_handler import ThumbnailDrawer

class CustomProcessingCoordinator:

    def __init__(
        self,
        file_reader: FileReader,
        meta_parser: MetaParser,
        graph_plotter: GraphPlotter,
        structured_processor: StructuredDataProcessor,
    ):
        self.file_reader = file_reader
        self.meta_parser = meta_parser
        self.graph_plotter = graph_plotter
        self.structured_processor = structured_processor


def custom_module(srcpaths: RdeInputDirPaths, resource_paths: RdeOutputResourcePath) -> None:
    coordinator = CustomProcessingCoordinator(FileReader(), MetaParser(), GraphPlotter(), StructuredDataProcessor())

    # Check input file
    coordinator.file_reader.check(srcpaths)

    # Read and Update Invoice
    invoice_file = srcpaths.invoice / 'invoice.json'
    invoice = InvoiceParser(invoice_file)
    invoice.backup()
    invoice.change_title()

    # Read input data
    meta, df_data = coordinator.file_reader.read(srcpaths)

    #from pprint import pprint
    #pprint(meta)
    #pprint(df_data)

    # Meta
    coordinator.meta_parser.parse_from_invoice(invoice.invoice_obj)
    coordinator.meta_parser.parse_from_inputdata(meta, df_data)
    coordinator.meta_parser.save_meta(
        resource_paths.meta.joinpath("metadata.json"),
        Meta(srcpaths.tasksupport.joinpath("metadata-def.json"))
    )

    # Save csv
    coordinator.structured_processor.to_csv(df_data, resource_paths.struct)

    # Graph
    const_meta_info = coordinator.meta_parser.const_meta_info
    coordinator.graph_plotter.plot(
        df_data,
        resource_paths,
        title=const_meta_info["data_title"],
        xlabel=const_meta_info["x_label"],
        ylabel=const_meta_info["y_label"]
    )

    # Thumbnail
    thumbnail = ThumbnailDrawer()
    thumbnail.draw(resource_paths)

    # Copy inputdata to public (raw/) or non_public (nonshared_raw/)
    is_private_raw = invoice.is_private_raw
    raw_dir = resource_paths.nonshared_raw if is_private_raw else resource_paths.raw
    input_dir = srcpaths.inputdata
    input_file = input_dir / "sample.data"
    shutil.copy(input_file, raw_dir)


@catch_exception_with_message(error_message="ERROR: failed in data processing", error_code=50)
def dataset(srcpaths: RdeInputDirPaths, resource_paths: RdeOutputResourcePath) -> None:

    custom_module(srcpaths, resource_paths)
