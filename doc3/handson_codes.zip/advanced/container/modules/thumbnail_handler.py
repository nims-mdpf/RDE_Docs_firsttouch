from __future__ import annotations

from pathlib import Path

from rdetoolkit.models.rde2types import RdeOutputResourcePath
from rdetoolkit.img2thumb import resize_image


class ThumbnailDrawer():

    def draw(self, resource_paths: RdeOutputResourcePath) -> None:
        # Write thumbnail images
        src_img_file_path = resource_paths.main_image / "all_series.png"
        out_img_file_path = resource_paths.thumbnail / "thumbnail.png"

        # Size of thumbnail
        closure_w = 286
        closure_h = 200

        resize_image(
            src_img_file_path,
            closure_w,
            closure_h,
            out_img_file_path
        )
