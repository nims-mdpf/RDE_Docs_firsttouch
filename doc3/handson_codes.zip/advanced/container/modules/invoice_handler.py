from pathlib import Path

from rdetoolkit.errors import StructuredError
from rdetoolkit.invoicefile import InvoiceFile


class InvoiceParser():
    """RDE invoice.json handle
    """
    additional_title = "(2024)"

    def __init__(self):
        self.invoice_file = None
        self.invoice_obj = None
        self.raw_dir = None
        self.nonshared_raw_dir = None

    def parse(self, invoice_file):
        self.invoice_path = invoice_file
        self.invoice_obj = InvoiceFile(invoice_file)

    @property
    def is_private_raw(self) -> bool:
        if self.invoice_obj is None:
            raise StructuredError("ERROR: invoice does not set")

        invoice_dict = self.invoice_obj.invoice_obj
        # Check private or not
        custom = invoice_dict.get("custom")
        if custom is None:
            return False
        is_private_raw = custom.get("is_private_raw")
        if is_private_raw == "share":
            return False
        # other case -> "private"
        return True

    def set_dirs(self, *, raw_dir: Path|None = None, nonshared_raw_dir: Path|None = None):
        self.raw_dir = raw_dir
        self.nonshared_raw_dir = nonshared_raw_dir

    def change_title(self):
        if self.invoice_obj is None:
            raise StructuredError("ERROR: invoice does not set")
        # Update invoice title
        original_data_name = self.invoice_obj["basic"]["dataName"]
        additional_title = self.additional_title
        if original_data_name.find(additional_title) < 0:
            # update title if not applied yet
            self.invoice_obj["basic"]["dataName"] = \
                original_data_name + " / " + additional_title
            # Overwrite
            invoice_file_new = self.invoice_path
            self.invoice_obj.overwrite(invoice_file_new)

    def backup(self):
        # Backup(=Copy) invoice.json to shared/nonshared folder
        is_private_raw = self.is_private_raw
        invoice_file = self.invoice_path
        if is_private_raw:
            backup_dir = self.nonshared_raw_dir
        else:
            backup_dir = self.raw_dir
        # check backup dir
        if backup_dir is None:
            raise StructuredError("ERROR: backup dir does not set")

        invoice_backup_file = backup_dir / "invoice.json.orig"
        InvoiceFile.copy_original_invoice(invoice_file, invoice_backup_file)
