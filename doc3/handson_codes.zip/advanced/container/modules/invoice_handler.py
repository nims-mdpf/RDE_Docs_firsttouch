from pathlib import Path

from rdetoolkit.core import DirectoryOps
from rdetoolkit.invoicefile import InvoiceFile


class InvoiceParser(InvoiceFile):
    """RDE invoice.json handle
    """

    def __init__(self, invoiceFile):
        super().__init__(invoiceFile)

    @property
    def is_private_raw(self) -> bool:
        invoice_dict = self.invoice_obj
        # Check private or not
        custom = invoice_dict.get("custom")
        if custom is None:
            return False
        is_private_raw = custom.get("is_private_raw")
        if is_private_raw == "share":
            return False
        # other case -> "private"
        return True

    def change_title(self):
        # Update invoice title
        original_data_name = self.invoice_obj["basic"]["dataName"]
        additional_title = "(2024)"
        if original_data_name.find(additional_title) < 0:
            # update title if not applied yet
            self.invoice_obj["basic"]["dataName"] = \
                original_data_name + " / " + additional_title
            # Overwrite
            invoice_file_new = self.invoice_path
            self.overwrite(invoice_file_new)

    def backup(self):
        # Backup(=Copy) invoice.json to shared/nonshared folder
        is_private_raw = self.is_private_raw
        invoice_file = self.invoice_path
        ops = DirectoryOps("data")
        if is_private_raw:
            raw_dir = ops.nonshared_raw.path
        else:
            raw_dir = ops.raw.path
        invoice_file_backup = Path(raw_dir) / "invoice.json.orig"
        InvoiceFile.copy_original_invoice(invoice_file, invoice_file_backup)
