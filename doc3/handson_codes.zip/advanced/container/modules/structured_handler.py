from __future__ import annotations

from pathlib import Path

import pandas as pd

from modules.interfaces import IStructuredDataProcessor


class StructuredDataProcessor(IStructuredDataProcessor):

    def to_csv(self, dataframes: list[pd.DataFrame], save_path: Path, *, header: list[str] | None = None) -> None:
        # Write CSV file(s)
        for d in dataframes:
            fname = d.columns[1].replace(" ", "") + ".csv"
            csvFilePath = save_path / fname
            if header is not None:
                d.to_csv(csvFilePath, header=header, index=False)
            else:
                d.to_csv(csvFilePath, header=True, index=False)
