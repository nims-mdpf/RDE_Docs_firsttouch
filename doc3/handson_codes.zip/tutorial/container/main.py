import rdetoolkit
from rdetoolkit.config import Config, MultiDataTileSettings, SystemSettings

from modules import datasets_process


def main():
    config = Config(
        system=SystemSettings(
            save_raw=False,
            save_nonshared_raw=False,
            save_thumbnail_image=True,
        ),
    )

    rdetoolkit.workflows.run(
        config=config,
        custom_dataset_function=datasets_process.dataset
    )

if __name__ == '__main__':
    main()
