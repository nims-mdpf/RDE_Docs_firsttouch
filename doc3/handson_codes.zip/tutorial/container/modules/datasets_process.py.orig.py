from pprint import pprint

from rdetoolkit.errors import catch_exception_with_message
from rdetoolkit.exceptions import StructuredError
from rdetoolkit.models.rde2types import RdeDatasetPaths


@catch_exception_with_message(error_message="MESSAGE (B)", error_code=25)
def custom_module(paths: RdeDatasetPaths) -> None:
    #raise StructuredError('*** RDE ERROR ***', 200)
    #raise StructuredError()
    #1 / 0
    #l = 100
    #l.append(200)

@catch_exception_with_message(error_message="MESSAGE (A)", error_code=50)
def dataset(paths: RdeDatasetPaths) -> None:
    custom_module(paths)
